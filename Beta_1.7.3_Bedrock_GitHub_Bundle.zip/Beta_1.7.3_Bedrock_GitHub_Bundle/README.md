# Beta 1.7.3-inspired Bedrock Pack Collection

A curated collection of the latest versions developed in this project. These packs approximate selected Beta 1.7.3 rules in modern Minecraft Bedrock; they do not recreate the full historical game.

Target: **Bedrock 1.21.90 or newer**, stable Script API 2.0.0. Compatibility with every newer engine release has not been verified. No Beta APIs experiment is required by these manifests.

## Downloads

| Pack | Included version | Purpose |
| --- | --- | --- |
| Texture filter | [Beta_Block_and_Item_Filter_v1.2_Snowy_Grass_Only.mcpack](downloads/Beta_Block_and_Item_Filter_v1.2_Snowy_Grass_Only.mcpack) | Restores snowy grass textures while hiding newer blocks/items. |
| Inventory enforcer | [Beta_Inventory_Enforcer_v1.1_No_Wood_Slabs.mcpack](downloads/Beta_Inventory_Enforcer_v1.1_No_Wood_Slabs.mcpack) | Removes forbidden inventory items, including oak and petrified oak slabs. |
| Entity enforcer | [Beta_Entity_Enforcer_v1.1_No_Babies.mcaddon](downloads/Beta_Entity_Enforcer_v1.1_No_Babies.mcaddon) | Removes newer entities, baby mobs and XP orbs without normal death drops or poof. |
| Classic ores and planks | [Classic_Ore_Drops_and_Oak_Planks_v1.0.mcpack](downloads/Classic_Ore_Drops_and_Oak_Planks_v1.0.mcpack) | Normal iron/gold ore player mining drops ore blocks; plank recipes produce oak planks. |
| Optional permafrost | [Permafrost_Snow_and_Ice_v2.0.mcaddon](downloads/Permafrost_Snow_and_Ice_v2.0.mcaddon) | Converts detected snow layers and ice into custom blocks without melting behavior. |

## Install

1. Back up your world, then import the four core downloads into Minecraft. Import the permafrost add-on only if you want its custom-block behavior.
2. Enable the inventory enforcer, entity enforcer and classic ore/plank behavior packs in your world settings.
3. Enable the texture filter and entity enforcer resource packs. Put the entity enforcer resource pack above the texture filter.
4. If using permafrost, enable both its behavior and resource packs and put its resource pack above the texture filter too.
5. Disable older versions of each pack. Put the ore/plank behavior pack above other packs that override its recipes.

The snowy-grass texture copy intentionally retains the v1.2 manifest identity. If Minecraft rejects it as a duplicate, remove the installed v1.2 resource pack before importing the corrected copy.

## Included fixes and limits

- **Texture filter:** the v1.2 copy has only its snowy grass texture files restored. Other content is unchanged. Transparent textures can still render as solid/black on some opaque vanilla materials; this is not a guarantee that every blocked block is invisible.
- **Inventory:** oak slabs and petrified oak slabs are removed from the allowlist. Other wood slab types were already blocked. Cleanup covers inventory/hotbar, equipment and cursor every tick, including Creative players. It does not delete blocks already placed or items stored in chests, ender chests or on the ground. Colored beds have a cursor-only detection limitation; details are in the pack README.
- **Entities:** preserves chicken, pig, sheep, cow, squid, wolf, zombie, skeleton, spider, creeper, ghast, zombie pigman and slime, plus the allowed legacy utility entities. Babies and disallowed entity types are removed on spawn/periodic checks. Removal avoids normal death loot, XP and poof. XP orbs from all sources are removed; existing player XP levels remain. Small slimes remain allowed. Modern AI/mechanics are not reverted. Unknown future/custom entities are removed by the script but do not have prewritten texture or spawn overrides.
- **Ores/planks:** affects player mining of normal iron and gold ore with appropriate pickaxes. Deepslate ore, Nether gold, explosions and command destruction are not changed. Plank recipe inputs/counts are retained while outputs become oak; modern input items remain forbidden by the inventory enforcer.

## Optional snow and ice preservation

Permafrost v2.0 is the newest approach and replaces the unreliable restore-after-melt packs. It does **not** alter random tick speed. Converted custom blocks have no native melting behavior, and player mining removes them normally.

Existing native snow/ice is discovered progressively near players. Unconverted blocks can still melt before discovery; already melted blocks are not recovered. Native snowy-grass detection and some mining, lighting, translucency and piston behavior may differ because these are custom block identifiers.

Disable the old random-ticks-off pack and both old snow/ice restoration versions. If the old freeze pack left random tick speed at zero, restore it with `/gamerule randomtickspeed 1`.

Keep permafrost installed while converted blocks exist. To revert, run `/scriptevent classic_permafrost:revert`, visit converted areas and allow scanning, then exit and disable the add-on before reloading. Reversion mode lasts for the current session. Unvisited/deep custom blocks may need manual replacement. See its included README before uninstalling.

## Validation

Pack archives and manifests were checked. Individual packs received structural checks and simulated behavior tests during development. **No live Minecraft Bedrock client testing was available**, and combined-pack gameplay has not been verified.

## Repository contents

- `downloads/`: original installable files, copied without modifying pack contents.
- `source/`: unpacked contents of each selected pack for inspection/editing.
- `RELEASE_POST.md`: prepared GitHub release text.
- `SHA256SUMS.txt`: checksums of the installable downloads.

Minecraft assets included in the resource packs originate from Mojang's Bedrock samples. No new license grant is made for those assets. This project is not affiliated with Mojang or Microsoft.
